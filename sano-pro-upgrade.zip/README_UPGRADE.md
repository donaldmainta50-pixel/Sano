# Sano Trading AI — pack v1.1
1. Décompresse ce ZIP **à la racine** de ton projet (remplace backtest.py).
2. `python apply_upgrade.py`  (branche les nouvelles routes dans app.py)
3. `python -m unittest discover -s tests -v`
4. (Optionnel, vraies données OHLC) clé gratuite sur twelvedata.com :
   `export TWELVEDATA_API_KEY="ta_clé"`
5. `uvicorn app:app --host 0.0.0.0 --port 8000`
Nouveau : `/api/pro/signal/EUR%2FUSD?source=twelvedata&balance=1000&risk_pct=1`
