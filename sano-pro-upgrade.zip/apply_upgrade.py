from pathlib import Path
p = Path("app.py"); t = p.read_text(encoding="utf-8")
if "routes_pro" not in t:
    marker = 'app.mount("/static"'
    i = t.index(marker); j = t.index("\n", i)
    t = t[:j+1] + "import routes_pro\napp.include_router(routes_pro.router)\n" + t[j+1:]
    p.write_text(t, encoding="utf-8"); print("app.py mis à jour.")
else: print("Déjà appliqué.")
