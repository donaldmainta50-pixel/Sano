import indicators as ind
from risk import pip_size

def _metrics(trades, start):
    nets = [t["net"] for t in trades]
    wins = [n for n in nets if n > 0]; losses = [-n for n in nets if n < 0]
    eq = peak = dd = 0.0
    for n in nets:
        eq += n; peak = max(peak, eq); dd = max(dd, peak - eq)
    return {"trades": len(nets), "return_pct": sum(nets) / start * 100,
            "win_rate_pct": len(wins) / len(nets) * 100 if nets else 0.0,
            "profit_factor": sum(wins) / sum(losses) if losses else None,
            "max_drawdown_pct": dd / start * 100}

def run_ema_cross(candles, pair, spread_pips=1.5, fast=9, slow=21):
    if len(candles) < 60: raise ValueError("Pas assez de données pour le backtest (minimum 60 bougies).")
    if not 2 <= fast < slow: raise ValueError("fast doit être inférieur à slow.")
    closes = [float(c["c"]) for c in candles]
    f, s = ind.ema(closes, fast), ind.ema(closes, slow)
    spread = spread_pips * pip_size(pair)
    trades = []; pos = 0; entry = entry_t = None
    def close(px, t):  # signal sur la bougie i, exécution à l'ouverture suivante (pas de lookahead)
        g = (px - entry) * pos
        trades.append({"entry": entry_t, "exit": t, "side": "long" if pos > 0 else "short", "gross": g, "net": g - spread})
    for i in range(slow + 1, len(candles) - 1):
        if f[i] is None or s[i] is None: continue
        want = 1 if f[i] > s[i] else -1 if f[i] < s[i] else 0
        if pos and want != pos: close(float(candles[i + 1]["o"]), candles[i + 1]["t"]); pos = 0
        if not pos and want: pos = want; entry = float(candles[i + 1]["o"]); entry_t = candles[i + 1]["t"]
    if pos: close(float(candles[-1]["c"]), candles[-1]["t"])
    start = max(abs(closes[0]), 1e-9)
    g, n = sum(t["gross"] for t in trades), sum(t["net"] for t in trades)
    k = int(len(trades) * 0.7)
    ins, oos = _metrics(trades[:k], start), _metrics(trades[k:], start)
    warnings = []
    if len(trades) < 30: warnings.append("Échantillon trop petit pour tirer des conclusions (< 30 trades).")
    if k and ins["return_pct"] > 0 and oos["return_pct"] <= 0: warnings.append("Négatif hors échantillon : risque de surajustement.")
    st = lambda x: {"return_pct": x / start * 100, "profit_loss_units": x, "trades": len(trades)}
    return {"pair": pair, "trades": trades, "gross": st(g), "net": st(n), "metrics": _metrics(trades, start),
            "in_sample": ins, "out_of_sample": oos, "warnings": warnings,
            "method": f"EMA {fast}/{slow}, signal à la clôture, entrée à la bougie suivante; spread fixe, sans slippage/swap."}
