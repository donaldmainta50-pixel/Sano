def pip_size(pair):
    if pair.startswith("XAU"): return 0.1
    return 0.01 if pair.endswith("JPY") else 0.0001

def trade_plan(pair, side, entry, atr, balance, risk_pct=1.0, atr_stop=1.5, rr=2.0):
    """Plan de risque pédagogique basé sur l'ATR. Ne passe aucun ordre."""
    if side not in ("long", "short"): raise ValueError("side doit être long ou short.")
    if not atr or atr <= 0 or entry <= 0: raise ValueError("ATR/prix invalide.")
    if balance <= 0 or not 0 < risk_pct <= 5: raise ValueError("Capital > 0 et risque entre 0 et 5 % requis.")
    d = atr * atr_stop; sgn = 1 if side == "long" else -1
    risk_amt = balance * risk_pct / 100
    return {"side": side, "entry": entry, "stop": entry - sgn * d, "target": entry + sgn * d * rr,
            "stop_pips": d / pip_size(pair), "rr": rr, "risk_amount": risk_amt,
            "units_base_approx": risk_amt / d,
            "note": "Taille approximative en devise de base si le compte est en devise de cotation; à convertir sinon."}
