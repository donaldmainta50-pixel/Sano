from datetime import datetime, timezone
from fastapi import APIRouter, HTTPException
import config, providers, analysis, storage, signals, risk, twelvedata

router = APIRouter(prefix="/api/pro", tags=["pro"])

def _load(pair, tf, source):
    if source == "demo":
        return {"candles": providers.demo_candles(pair, tf), "is_demo": True, "notes": ["Données synthétiques."]}
    if source == "twelvedata":
        return {"candles": twelvedata.fetch(pair, tf), "is_demo": False, "notes": []}
    raise HTTPException(400, "Source inconnue (demo | twelvedata).")

@router.get("/signal/{pair:path}")
def signal(pair: str, source: str = "demo", balance: float = 1000, risk_pct: float = 1.0):
    pair = pair.upper()
    if pair not in config.PAIRS: raise HTTPException(400, "Paire non prise en charge.")
    settings, rows, now = storage.get_settings(), {}, datetime.now(timezone.utc)
    try:
        for tf in config.TIMEFRAMES:
            m = _load(pair, tf, source)
            rows[tf] = analysis.analyze_tf(m["candles"], settings, tf, {**m, "pair": pair}, now)
    except HTTPException: raise
    except Exception as e: raise HTTPException(502, f"Données indisponibles: {e}")
    conf = signals.confluence(rows)
    ok = [r for r in rows.values() if r.get("ok")]
    fresh = bool(ok) and all(r["quality"]["freshness"] == "récent" for r in ok)
    plan = None
    base = rows.get("4h", {})
    if conf["bias"] in ("haussier", "baissier") and base.get("ok") and base.get("atr"):
        px = rows["1h"]["last"] if rows.get("1h", {}).get("ok") else base["last"]
        try: plan = risk.trade_plan(pair, "long" if conf["bias"] == "haussier" else "short", px, base["atr"], balance, risk_pct)
        except ValueError as e: raise HTTPException(400, str(e))
    return {"pair": pair, "source": source, "confluence": conf, "fresh_data": fresh,
            "actionable": source != "demo" and fresh and plan is not None, "risk_plan": plan,
            "timeframes": {tf: {k: r.get(k) for k in ("direction", "last", "rsi", "atr")} | {"freshness": r.get("quality", {}).get("freshness")} for tf, r in rows.items() if r.get("ok")},
            "disclaimer": "Aide à l'analyse uniquement : aucune garantie, aucun ordre envoyé."}
