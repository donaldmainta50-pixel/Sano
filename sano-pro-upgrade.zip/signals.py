W = {"1d": 3, "4h": 2, "1h": 1}

def confluence(rows):
    """Agrège la direction des unités de temps (poids 1d>4h>1h)."""
    score = used = 0; notes = []
    for tf, r in rows.items():
        if not r.get("ok"): notes.append(f"{tf}: données insuffisantes"); continue
        w = W.get(tf, 1); used += w
        score += w * {"haussier": 1, "baissier": -1}.get(r["direction"], 0)
    if not used: return {"bias": "indéterminé", "score": 0, "max": 0, "strength": "nulle", "notes": notes}
    ratio = abs(score) / used
    bias = "neutre" if ratio < 0.34 else ("haussier" if score > 0 else "baissier")
    strength = "forte" if ratio >= 0.8 else "moyenne" if ratio >= 0.5 else "faible"
    dirs = {r["direction"] for r in rows.values() if r.get("ok") and r["direction"] != "mixte"}
    if len(dirs) > 1: notes.append("Conflit entre unités de temps : prudence.")
    for tf, r in rows.items():
        rsi = r.get("rsi") if r.get("ok") else None
        if rsi is not None and bias == "haussier" and rsi >= 70: notes.append(f"{tf}: RSI suracheté ({rsi:.0f}).")
        if rsi is not None and bias == "baissier" and rsi <= 30: notes.append(f"{tf}: RSI survendu ({rsi:.0f}).")
    return {"bias": bias, "score": score, "max": used, "strength": strength, "notes": notes}
