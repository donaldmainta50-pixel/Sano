import os, sys, random, unittest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import backtest, risk, signals, twelvedata

def candles(n=600, seed=7):
    rng = random.Random(seed); p = 1.1; out = []
    for i in range(n):
        o = p; p += rng.gauss(.0001 if (i // 100) % 2 == 0 else -.0001, .002)
        out.append({"t": f"t{i}", "o": o, "h": max(o, p) + .0005, "l": min(o, p) - .0005, "c": p})
    return out

class Pro(unittest.TestCase):
    def test_pip(self): self.assertEqual((risk.pip_size("XAU/USD"), risk.pip_size("USD/JPY"), risk.pip_size("EUR/USD")), (0.1, 0.01, 0.0001))
    def test_plan_long_short(self):
        l = risk.trade_plan("EUR/USD", "long", 1.1, 0.002, 1000, 1)
        self.assertAlmostEqual(l["stop"], 1.097); self.assertAlmostEqual(l["target"], 1.106); self.assertAlmostEqual(l["risk_amount"], 10)
        s = risk.trade_plan("EUR/USD", "short", 1.1, 0.002, 1000, 1)
        self.assertGreater(s["stop"], 1.1); self.assertLess(s["target"], 1.1)
    def test_plan_rejects_bad(self):
        for kw in ({"risk_pct": 10}, {"balance": 0}, {"atr": 0}):
            a = dict(pair="EUR/USD", side="long", entry=1.1, atr=.002, balance=1000); a.update(kw)
            with self.assertRaises(ValueError): risk.trade_plan(**a)
    def test_confluence(self):
        r = lambda d, rsi=50: {"ok": True, "direction": d, "rsi": rsi}
        self.assertEqual(signals.confluence({"1d": r("haussier"), "4h": r("haussier"), "1h": r("haussier")})["strength"], "forte")
        c = signals.confluence({"1d": r("haussier"), "4h": r("baissier"), "1h": r("baissier")})
        self.assertEqual(c["bias"], "neutre"); self.assertTrue(any("Conflit" in n for n in c["notes"]))
        self.assertTrue(any("suracheté" in n for n in signals.confluence({"1d": r("haussier", 75)})["notes"]))
        self.assertEqual(signals.confluence({"1d": {"ok": False}})["bias"], "indéterminé")
    def test_backtest_metrics(self):
        r = backtest.run_ema_cross(candles(), "EUR/USD")
        for k in ("metrics", "in_sample", "out_of_sample"): self.assertIn(k, r)
        self.assertGreaterEqual(r["metrics"]["max_drawdown_pct"], 0)
        self.assertAlmostEqual(r["metrics"]["return_pct"], r["net"]["return_pct"], places=6)
        self.assertLessEqual(r["net"]["return_pct"], r["gross"]["return_pct"])
    def test_backtest_params(self):
        with self.assertRaises(ValueError): backtest.run_ema_cross(candles(), "EUR/USD", fast=30, slow=10)
    def test_twelvedata_parse(self):
        out = twelvedata.parse({"values": [{"datetime": "2026-01-02 10:00:00", "open": "1.1", "high": "1.2", "low": "1.0", "close": "1.15"},
                                           {"datetime": "2026-01-02 09:00:00", "open": "1", "high": "1.1", "low": "0.9", "close": "1.1"}]})
        self.assertEqual(out[0]["t"], "2026-01-02T09:00:00+00:00"); self.assertEqual(out[1]["c"], 1.15)
        with self.assertRaises(ValueError): twelvedata.parse({"status": "error", "message": "quota"})
    def test_twelvedata_needs_key(self):
        os.environ.pop("TWELVEDATA_API_KEY", None)
        with self.assertRaises(ValueError): twelvedata.fetch("EUR/USD")

if __name__ == "__main__": unittest.main()
