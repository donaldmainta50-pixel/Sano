import json, os
from urllib.parse import quote
from urllib.request import Request, urlopen

INTERVAL = {"1h": "1h", "4h": "4h", "1d": "1day"}

def parse(payload):
    if payload.get("status") == "error": raise ValueError(payload.get("message", "Erreur Twelve Data"))
    rows = payload.get("values") or []
    if not rows: raise ValueError("Aucune donnée retournée.")
    out = []
    for v in reversed(rows):  # l'API renvoie du plus récent au plus ancien
        t = v["datetime"].replace(" ", "T")
        if "T" not in t: t += "T00:00:00"
        out.append({"t": t + "+00:00", "o": float(v["open"]), "h": float(v["high"]), "l": float(v["low"]), "c": float(v["close"])})
    return out

def fetch(pair, timeframe="1h", size=240, api_key=None, timeout=10):
    key = api_key or os.environ.get("TWELVEDATA_API_KEY")
    if not key: raise ValueError("Variable TWELVEDATA_API_KEY manquante (clé gratuite sur twelvedata.com).")
    url = f"https://api.twelvedata.com/time_series?symbol={quote(pair)}&interval={INTERVAL[timeframe]}&outputsize={size}&timezone=UTC&apikey={key}"
    try:
        with urlopen(Request(url, headers={"User-Agent": "SanoTradingAI/1.1"}), timeout=timeout) as r:
            return parse(json.loads(r.read().decode()))
    except ValueError: raise
    except Exception: raise ValueError("Requête Twelve Data échouée (réseau, quota ou clé invalide).")  # ne jamais exposer l'URL/clé
